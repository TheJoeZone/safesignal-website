
# SafeSignal Advisor - Anti-Scam Website

A professional Next.js website for SafeSignal Advisor, providing expert analysis of suspicious emails, SMS, and communications to help users identify and avoid scams.

## Features

- 🛡️ **Professional Scam Analysis Service** - Human-powered expert review of suspicious communications
- 🌍 **Multi-language Support** - Available in English, German, French, and Italian
- 💰 **Flexible Pricing Plans** - Starter, Growth, and Unlimited tiers with CHF pricing
- 📧 **Contact Form** - Integrated form with database storage for inquiries
- 📱 **Responsive Design** - Mobile-first design with Tailwind CSS
- 🔒 **Privacy-First** - Comprehensive privacy policy and terms of service
- ⚡ **Performance Optimized** - Built with Next.js 14 and optimized for speed

## Project Structure

```
app/
├── app/
│   ├── layout.tsx          # Root layout with metadata
│   ├── page.tsx           # Home page
│   ├── globals.css        # Global styles
│   └── api/
│       └── contact/
│           └── route.ts   # Contact form API endpoint
├── components/
│   ├── main-content.tsx   # Main page container
│   ├── header.tsx         # Navigation header
│   ├── hero.tsx          # Hero section
│   ├── trust-bar.tsx     # Trust indicators
│   ├── language-support.tsx # Multi-language section
│   ├── how-it-works.tsx  # Process explanation
│   ├── pricing.tsx       # Pricing plans
│   ├── free-trial.tsx    # Free trial CTA
│   ├── features.tsx      # Key features
│   ├── faq.tsx          # FAQ section
│   ├── cta.tsx          # Contact form
│   ├── footer.tsx       # Site footer
│   ├── privacy-policy.tsx # Privacy policy page
│   └── terms-of-service.tsx # Terms of service page
├── prisma/
│   └── schema.prisma     # Database schema
└── lib/
    └── types.ts          # TypeScript type definitions
```

## Tech Stack

- **Framework:** Next.js 14 with App Router
- **Styling:** Tailwind CSS
- **Database:** Prisma with SQLite (configurable)
- **Icons:** Lucide React
- **TypeScript:** Full type safety
- **Responsive:** Mobile-first design

## Getting Started

### Prerequisites
- Node.js 18+ 
- Yarn package manager

### Installation

1. Install dependencies:
   ```bash
   cd app
   yarn install
   ```

2. Set up the database:
   ```bash
   yarn prisma generate
   yarn prisma db push
   ```

3. Start the development server:
   ```bash
   yarn dev
   ```

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Database Setup

The project uses Prisma with SQLite for development. To set up:

```bash
# Generate Prisma client
yarn prisma generate

# Create and sync database
yarn prisma db push

# View database (optional)
yarn prisma studio
```

For production, update the `DATABASE_URL` in `.env` to use PostgreSQL or your preferred database.

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Connect your repository to Vercel
3. Configure environment variables in Vercel dashboard
4. Deploy automatically

### Environment Variables for Production

```bash
DATABASE_URL="your-production-database-url"
NEXT_PUBLIC_APP_URL="https://yourdomain.com"
```

## Customization

### Pricing Plans
Edit the pricing data in `components/main-content.tsx`:
```typescript
const pricing = [
  {
    name: "Starter",
    price: "29 CHF/mo",
    // ... update features and Stripe links
  }
]
```

### Contact Form
The contact form automatically saves submissions to the database. View submissions with:
```bash
yarn prisma studio
```

### Styling
- Global styles: `app/globals.css`
- Component styles: Tailwind classes in each component
- Custom animations: Defined in globals.css

## Key Features

### Multi-language Support
- Primary: English
- Secondary: German, French, Italian (on request)
- Language selection in contact form

### Contact Form Integration
- Form validation
- Database storage
- Success/error feedback
- Prisma ORM integration

### SEO Optimization
- Meta tags in layout.tsx
- Semantic HTML structure
- Open Graph tags
- Proper heading hierarchy

### Accessibility
- ARIA labels
- Keyboard navigation
- Focus management
- Screen reader compatibility

## Support

For technical questions about the website implementation, check the code comments and component documentation.

For business inquiries about SafeSignal Advisor services, use the contact form on the website.

## License

This project is for SafeSignal Advisor's exclusive use. All rights reserved.
