
import MainContent from '@/components/main-content'

export default function Home() {
  return <MainContent />
}
