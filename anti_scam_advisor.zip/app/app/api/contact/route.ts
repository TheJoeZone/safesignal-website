
import { NextRequest, NextResponse } from 'next/server'

// For development - we'll log contacts to console instead of database
// In production, you can uncomment the Prisma code below
// import { PrismaClient } from '@prisma/client'
// const prisma = new PrismaClient()

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, language, message } = body

    // Basic validation
    if (!name || !email || !message) {
      return NextResponse.json(
        { error: 'Name, email, and message are required' },
        { status: 400 }
      )
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Invalid email address' },
        { status: 400 }
      )
    }

    // For development - log to console (replace with database save in production)
    const contactData = {
      name: name.trim(),
      email: email.toLowerCase().trim(),
      language: language || 'en',
      message: message.trim(),
      status: 'new',
      formType: 'general_inquiry',
      timestamp: new Date().toISOString()
    }
    
    console.log('📧 New Contact Form Submission:', contactData)
    
    /* 
    // Uncomment for database integration:
    const contact = await prisma.contact.create({
      data: contactData
    })
    */

    return NextResponse.json(
      { 
        success: true, 
        message: 'Thank you for your message. We will get back to you within 24 hours.',
        id: `temp_${Date.now()}` 
      },
      { status: 200 }
    )

  } catch (error) {
    console.error('Contact form error:', error)
    
    return NextResponse.json(
      { error: 'Something went wrong. Please try again later.' },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json(
    { message: 'Contact API endpoint is working' },
    { status: 200 }
  )
}
