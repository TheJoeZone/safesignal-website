
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'SafeSignal Advisor - Anti-Scam Email & SMS Protection Service',
  description: 'Professional scam protection service for Switzerland. Forward suspicious emails and SMS for expert analysis. Human-powered with multilingual support in EN, DE, FR, IT.',
  keywords: 'scam protection, email security, SMS security, phishing protection, Switzerland, cybersecurity, fraud prevention',
  authors: [{ name: 'SafeSignal Advisor' }],
  openGraph: {
    title: 'SafeSignal Advisor - Professional Scam Protection Service',
    description: 'Get expert analysis of suspicious emails and SMS. Swiss-based privacy-first service with multilingual support.',
    type: 'website',
    locale: 'en_US',
  }
}

export function generateViewport() {
  return {
    width: 'device-width',
    initialScale: 1,
  }
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22https://www.pngfind.com/pngs/m/59-599855_shield-icon-shield-emoji-hd-png-download.png viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>🛡️</text></svg>" />
      </head>
      <body className={inter.className}>
        {children}
      </body>
    </html>
  )
}
