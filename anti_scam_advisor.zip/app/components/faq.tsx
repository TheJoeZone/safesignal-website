
import { ChevronDown, ChevronUp } from 'lucide-react'

interface FAQProps {
  faqs: { q: string; a: string; }[];
  active: number | null;
  onToggle: (i: number) => void;
}

export default function FAQ({ faqs, active, onToggle }: FAQProps) {
  return (
    <section id="faq" className="py-16 bg-gray-50">
      <div className="max-w-3xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center">Frequently asked questions</h2>
        <div className="mt-8 divide-y divide-gray-200 border border-gray-200 rounded-lg bg-white">
          {faqs?.map((f, i) => (
            <div key={i} className="p-5">
              <button 
                className="w-full flex items-center justify-between text-left hover:text-blue-600 transition-colors" 
                onClick={() => onToggle?.(i)}
              >
                <span className="font-medium">{f?.q}</span>
                {active === i ? <ChevronUp className="w-5 h-5 text-gray-500" /> : <ChevronDown className="w-5 h-5 text-gray-500" />}
              </button>
              {active === i && <p className="mt-3 text-gray-600 text-sm animate-fade-in">{f?.a}</p>}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
