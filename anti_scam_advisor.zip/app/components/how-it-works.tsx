
import { FileCheck, Mail, Search, Lightbulb } from 'lucide-react'

export default function HowItWorks() {
  const steps = [
    {
      title: "Subscribe to a plan",
      desc: "Pick the coverage you need. You'll receive your dedicated forwarding address right away.",
      icon: <FileCheck className="w-8 h-8" />,
    },
    {
      title: "Forward anything suspicious",
      desc: "Emails, screenshots of SMS, or call notes. No need to explain—just forward.",
      icon: <Mail className="w-8 h-8" />,
    },
    {
      title: "Get a clear verdict",
      desc: "We reply with Legit/Scam, red flags found, and safe next steps.",
      icon: <Search className="w-8 h-8" />,
    },
    {
      title: "Stay safer over time",
      desc: "We teach patterns scammers use so you can spot them instantly.",
      icon: <Lightbulb className="w-8 h-8" />,
    },
  ];

  return (
    <section id="how" className="py-16">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center">How it works</h2>
        <p className="mt-2 text-center text-gray-600">Simple steps to get trustworthy answers fast.</p>
        <div className="mt-10 grid md:grid-cols-4 gap-6">
          {steps.map((s, i) => (
            <div key={i} className="p-6 rounded-lg bg-white border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="text-blue-600 mb-4">{s.icon}</div>
              <h3 className="font-semibold">{s.title}</h3>
              <p className="text-gray-600 text-sm mt-2">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
