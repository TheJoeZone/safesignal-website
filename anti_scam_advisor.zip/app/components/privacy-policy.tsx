
import { ArrowLeft, Shield, Lock, Eye } from 'lucide-react'

interface PrivacyPolicyProps {
  onBack: () => void;
}

export default function PrivacyPolicy({ onBack }: PrivacyPolicyProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <button 
          onClick={onBack} 
          className="mb-6 flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to website
        </button>
        <div className="bg-white rounded-lg shadow p-8">
          <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
          <div className="prose max-w-none">
            <p className="text-gray-600 mb-4">Last updated: {new Date().toLocaleDateString()}</p>
            
            <div className="p-4 rounded-lg bg-green-50 border border-green-200 mb-6">
              <h3 className="text-lg font-semibold text-green-800 mb-2 flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Our Privacy Promise
              </h3>
              <p className="text-green-700 text-sm">
                <strong>We never ask for access to your email accounts, passwords, or personal information.</strong> 
                We only work with the specific content you choose to forward to us for analysis. 
                We do not request, store, or access any of your personal accounts or data beyond what you explicitly provide.
              </p>
            </div>
            
            <h2 className="text-xl font-semibold mt-6 mb-3 flex items-center gap-2">
              <Eye className="w-5 h-5" />
              1. Information We Collect
            </h2>
            <p className="mb-4">We collect information you provide directly to us, including:</p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Contact information (name, email address) - only when you contact us</li>
              <li>Forwarded emails, SMS screenshots, and call descriptions that you choose to send us for analysis</li>
              <li>Payment information (processed securely through Stripe - we never store your payment details)</li>
              <li>Communication preferences and language settings</li>
            </ul>
            <div className="bg-blue-50 p-4 rounded border-l-4 border-blue-400 mb-6">
              <p className="text-sm">
                <strong>Important:</strong> We never request access to your email accounts, social media, or any other personal accounts. 
                We only analyze the specific content you forward to us.
              </p>
            </div>

            <h2 className="text-xl font-semibold mt-6 mb-3">2. How We Use Your Information</h2>
            <p className="mb-4">We use the information we collect to:</p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Provide scam analysis and advisory services for the content you send us</li>
              <li>Communicate with you about our services and your specific requests</li>
              <li>Process payments for our services</li>
              <li>Improve our detection capabilities (using anonymized data patterns only)</li>
              <li>Send you educational content about scam prevention (if you opt-in)</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-3 flex items-center gap-2">
              <Lock className="w-5 h-5" />
              3. Information Sharing and Disclosure
            </h2>
            <p className="mb-4">We do not sell, trade, or otherwise transfer your personal information to third parties. We may share information only in these limited circumstances:</p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li><strong>Service Providers:</strong> We may use trusted third-party services (like Stripe for payments) that assist in our operations</li>
              <li><strong>Legal Requirements:</strong> We may disclose information if required by law or to protect our legal rights</li>
              <li><strong>Safety:</strong> We may share information if we believe it's necessary to prevent harm or illegal activity</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-3">4. Data Security</h2>
            <p className="mb-4">We implement appropriate security measures to protect your personal information:</p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>All data is encrypted in transit and at rest</li>
              <li>Access to your information is limited to authorized personnel only</li>
              <li>We regularly review our security practices and update them as needed</li>
              <li>Suspicious content is analyzed in isolated environments</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-3">5. Data Retention</h2>
            <p className="mb-4">We retain your information for as long as necessary to provide our services:</p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Contact information: Until you request deletion or close your account</li>
              <li>Analyzed content: 30 days after analysis (for follow-up questions), then securely deleted</li>
              <li>Payment records: As required by applicable tax and financial regulations</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-3">6. Your Rights</h2>
            <p className="mb-4">You have the right to:</p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Access the personal information we have about you</li>
              <li>Correct inaccurate or incomplete information</li>
              <li>Request deletion of your personal information</li>
              <li>Object to processing of your personal information</li>
              <li>Request a copy of your data in a portable format</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-3">7. Contact Us</h2>
            <p className="mb-4">If you have any questions about this Privacy Policy or our practices, please contact us:</p>
            <ul className="list-none mb-4 space-y-2">
              <li><strong>Email:</strong> privacy@safesignaladvisor.com</li>
              <li><strong>Subject Line:</strong> "Privacy Policy Question"</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-3">8. Changes to This Policy</h2>
            <p className="mb-4">
              We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page 
              and updating the "Last updated" date. You are advised to review this Privacy Policy periodically for any changes.
            </p>

            <div className="mt-8 p-4 rounded-lg bg-gray-100">
              <h3 className="font-semibold mb-2">Swiss Privacy Compliance</h3>
              <p className="text-sm text-gray-700">
                As a Switzerland-based service, we comply with Swiss Federal Act on Data Protection (FADP) and applicable EU regulations for 
                cross-border data transfers.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
