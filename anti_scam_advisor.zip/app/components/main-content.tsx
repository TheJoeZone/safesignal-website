
'use client'

import { useState } from 'react'
import Header from './header'
import Hero from './hero'
import TrustBar from './trust-bar'
import LanguageSupport from './language-support'
import HowItWorks from './how-it-works'
import Pricing from './pricing'
import FreeTrial from './free-trial'
import Features from './features'
import FAQ from './faq'
import CTA from './cta'
import Footer from './footer'
import PrivacyPolicy from './privacy-policy'
import TermsOfService from './terms-of-service'

const pricing = [
  {
    name: "Starter",
    price: "29 CHF/mo",
    highlight: false,
    features: [
      "Includes 1 free first email or 15-min advisory",
      "Up to 20 forwarded emails analyzed",
      "Quick verdict: Legit or Scam",
      "Risk notes + recommended action",
      "Basic phishing checks",
      "2 suspicious SMS checks"
    ],
    cta: "Choose Starter",
    stripeLink: "https://buy.stripe.com/starter-plan",
  },
  {
    name: "Growth",
    price: "49 CHF/mo",
    highlight: true,
    features: [
      "Includes 1 free first email or 15-min advisory",
      "Up to 50 forwarded emails analyzed",
      "Detailed analysis with red flags",
      "Attachment & link safety review",
      "Priority response (within 6 hours)",
      "5 suspicious SMS checks"
    ],
    cta: "Choose Growth",
    stripeLink: "https://buy.stripe.com/growth-plan",
  },
  {
    name: "Unlimited",
    price: "79 CHF/mo",
    highlight: false,
    features: [
      "Includes 1 free first email or 15-min advisory",
      "Unlimited email checks",
      "Unlimited suspicious SMS checks",
      "Ongoing protection advice",
      "Personalized scam watchlist",
      "Monthly security tips"
    ],
    cta: "Choose Unlimited",
    stripeLink: "https://buy.stripe.com/unlimited-plan",
  },
];

const faqs = [
  {
    q: "How do I forward suspicious emails to you?",
    a: "After subscribing, you'll receive a dedicated forwarding address (e.g., review@yoursafeadvisor.com). Simply forward the email, and we'll reply with an analysis and recommended action.",
  },
  {
    q: "How fast is the response?",
    a: "Starter and Unlimited plans are typically within 12 hours; Growth includes priority response within 6 hours. During business peaks we still aim to reply same-day.",
  },
  {
    q: "Do you ever open risky attachments?",
    a: "We analyze headers, URLs, and file metadata safely. We never execute unknown attachments. If deeper forensics is needed, we do it in isolated environments.",
  },
  {
    q: "Can you check phone calls or voicemails?",
    a: "Yes. Send a short summary, a screenshot, or transcript, and we'll assess red flags and advise on next steps.",
  },
  {
    q: "Is this a replacement for antivirus?",
    a: "No. We complement your security by catching social engineering and impersonation attempts that AV often misses.",
  },
  {
    q: "What languages do you support?",
    a: "Our service is primarily available in English, but we can localize our responses to German (DE), French (FR), or Italian (IT) upon request. Just mention your preferred language when forwarding emails.",
  },
  {
    q: "How does the free trial work?",
    a: "Your first suspicious email analysis or a 15-minute advisory call is completely free. No credit card required. Simply contact us with your question and we'll provide our full analysis at no charge.",
  },
];

export default function MainContent() {
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  
  const toggleFaq = (i: number) => setActiveFaq(activeFaq === i ? null : i);

  if (showPrivacy) {
    return <PrivacyPolicy onBack={() => setShowPrivacy(false)} />;
  }

  if (showTerms) {
    return <TermsOfService onBack={() => setShowTerms(false)} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <Header onShowPrivacy={() => setShowPrivacy(true)} onShowTerms={() => setShowTerms(true)} />
      <Hero />
      <TrustBar />
      <LanguageSupport />
      <HowItWorks />
      <Pricing cards={pricing} />
      <FreeTrial />
      <Features />
      <FAQ faqs={faqs} active={activeFaq} onToggle={toggleFaq} />
      <CTA />
      <Footer onShowPrivacy={() => setShowPrivacy(true)} onShowTerms={() => setShowTerms(true)} />
    </div>
  );
}
