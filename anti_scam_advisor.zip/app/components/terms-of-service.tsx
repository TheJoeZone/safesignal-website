
import { ArrowLeft, FileText, Shield, AlertTriangle } from 'lucide-react'

interface TermsOfServiceProps {
  onBack: () => void;
}

export default function TermsOfService({ onBack }: TermsOfServiceProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <button 
          onClick={onBack} 
          className="mb-6 flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to website
        </button>
        <div className="bg-white rounded-lg shadow p-8">
          <h1 className="text-3xl font-bold mb-6 flex items-center gap-2">
            <FileText className="w-8 h-8" />
            Terms of Service
          </h1>
          <div className="prose max-w-none">
            <p className="text-gray-600 mb-4">Last updated: {new Date().toLocaleDateString()}</p>
            
            <div className="p-4 rounded-lg bg-blue-50 border border-blue-200 mb-6">
              <h3 className="text-lg font-semibold text-blue-800 mb-2 flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Service Overview
              </h3>
              <p className="text-blue-700 text-sm">
                SafeSignal Advisor provides expert analysis of potentially suspicious emails, SMS messages, and communications 
                to help you identify scams and protect yourself from fraud. By using our service, you agree to these terms.
              </p>
            </div>
            
            <h2 className="text-xl font-semibold mt-6 mb-3">1. Acceptance of Terms</h2>
            <p className="mb-4">
              By accessing or using SafeSignal Advisor's services, you agree to be bound by these Terms of Service and our Privacy Policy. 
              If you do not agree to these terms, please do not use our service.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-3">2. Service Description</h2>
            <p className="mb-4">SafeSignal Advisor provides:</p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Analysis of forwarded emails, SMS messages, and communication descriptions</li>
              <li>Assessment of potential scams, phishing attempts, and fraudulent communications</li>
              <li>Educational guidance on recognizing and avoiding future scams</li>
              <li>Multilingual support in English, German, French, and Italian</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-3">3. User Responsibilities</h2>
            <p className="mb-4">When using our service, you agree to:</p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Provide accurate contact information</li>
              <li>Only forward content you have legal right to share</li>
              <li>Not forward illegal, harmful, or inappropriate content</li>
              <li>Not use our service for any unlawful purposes</li>
              <li>Respect our analysis and not misuse our responses</li>
            </ul>

            <div className="bg-yellow-50 p-4 rounded border-l-4 border-yellow-400 mb-6">
              <h3 className="flex items-center gap-2 font-semibold text-yellow-800 mb-2">
                <AlertTriangle className="w-5 h-5" />
                Important Limitations
              </h3>
              <ul className="text-yellow-700 text-sm space-y-1">
                <li>• Our analysis is advisory only and not a guarantee</li>
                <li>• We cannot prevent all scams or guarantee 100% accuracy</li>
                <li>• You remain responsible for your own security decisions</li>
                <li>• We are not liable for any losses from scams or our analysis</li>
              </ul>
            </div>

            <h2 className="text-xl font-semibold mt-6 mb-3">4. Payment Terms</h2>
            <p className="mb-4">For paid subscriptions:</p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Payments are processed through Stripe</li>
              <li>Subscriptions renew automatically unless cancelled</li>
              <li>You can cancel anytime through your account or by contacting us</li>
              <li>Refunds are handled on a case-by-case basis</li>
              <li>Prices include applicable Swiss VAT where required</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-3">5. Service Availability</h2>
            <p className="mb-4">We strive to provide reliable service but cannot guarantee:</p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Uninterrupted access to our services</li>
              <li>Specific response times (though we aim for same-day responses)</li>
              <li>Analysis of all types of content (we reserve the right to decline)</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-3">6. Intellectual Property</h2>
            <p className="mb-4">
              Our analysis methods, educational content, and service materials are our intellectual property. 
              You may not reproduce, distribute, or create derivative works from our content without permission.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-3">7. Limitation of Liability</h2>
            <p className="mb-4">
              SafeSignal Advisor provides advisory services only. We are not responsible for:
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Financial losses from scams or fraud</li>
              <li>Decisions made based on our analysis</li>
              <li>Technical issues or service interruptions</li>
              <li>Third-party actions or services</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-3">8. Privacy and Data</h2>
            <p className="mb-4">
              Your privacy is important to us. Please review our Privacy Policy, which explains how we collect, 
              use, and protect your information. By using our service, you also agree to our privacy practices.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-3">9. Termination</h2>
            <p className="mb-4">
              Either party may terminate this agreement at any time. Upon termination:
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-2">
              <li>Your access to paid services will end</li>
              <li>We will delete your data according to our privacy policy</li>
              <li>Any outstanding payment obligations remain</li>
            </ul>

            <h2 className="text-xl font-semibold mt-6 mb-3">10. Governing Law</h2>
            <p className="mb-4">
              These terms are governed by Swiss law. Any disputes will be resolved in Swiss courts, 
              with jurisdiction in the canton where SafeSignal Advisor is registered.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-3">11. Changes to Terms</h2>
            <p className="mb-4">
              We may update these terms from time to time. We will notify users of significant changes 
              and post updated terms on our website with a new "Last updated" date.
            </p>

            <h2 className="text-xl font-semibold mt-6 mb-3">12. Contact Information</h2>
            <p className="mb-4">For questions about these terms, contact us:</p>
            <ul className="list-none mb-4 space-y-2">
              <li><strong>Email:</strong> legal@safesignaladvisor.com</li>
              <li><strong>Subject Line:</strong> "Terms of Service Question"</li>
            </ul>

            <div className="mt-8 p-4 rounded-lg bg-gray-100">
              <h3 className="font-semibold mb-2">Swiss Business Information</h3>
              <p className="text-sm text-gray-700">
                SafeSignal Advisor operates under Swiss law and regulations. Our services are provided from Switzerland, 
                and all business practices comply with applicable Swiss federal and cantonal requirements.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
