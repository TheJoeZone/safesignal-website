
import { Gift } from 'lucide-react'

export default function FreeTrial() {
  return (
    <section id="free-trial" className="py-16 bg-green-600 text-white text-center">
      <div className="max-w-3xl mx-auto px-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-500 text-white text-xs font-medium mb-4">
          <Gift className="w-3 h-3" />
          No Risk Trial
        </div>
        <h2 className="text-3xl font-bold">Try it free — No commitment</h2>
        <p className="mt-4 text-lg">
          Your first suspicious email analysis or a <strong>15‑minute advisory call</strong> is completely <strong>free of charge</strong>.
          Test our service and see the value before you subscribe.
        </p>
        <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
          <a 
            href="#contact" 
            className="px-6 py-3 rounded-md bg-white text-green-700 font-semibold shadow hover:bg-gray-50 transition-colors"
          >
            Claim your free analysis
          </a>
          <a 
            href="#pricing" 
            className="px-6 py-3 rounded-md border-2 border-white text-white font-semibold hover:bg-white hover:text-green-700 transition-colors"
          >
            View paid plans
          </a>
        </div>
        <p className="mt-4 text-sm opacity-90">✅ No credit card required  ✅ No signup needed  ✅ Get results in 24 hours</p>
      </div>
    </section>
  );
}
