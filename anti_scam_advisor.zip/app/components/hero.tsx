
import Image from 'next/image'
import { Shield, Zap, Lock } from 'lucide-react'

export default function Hero() {
  return (
    <section id="home" className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-blue-50 to-transparent"></div>
      <div className="max-w-6xl mx-auto px-4 pt-14 pb-20 grid md:grid-cols-2 gap-8 items-center relative">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-xs font-medium mb-4">
            <Shield className="w-3 h-3" />
            Scam Protection Advisor
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold leading-tight text-gray-900">
            Get peace of mind: forward suspect emails, SMS, or calls for <span className="text-blue-600">expert review</span>
          </h1>
          <p className="mt-4 text-gray-600 text-lg">
            I help you recognize common scams online, in email, and by phone. Quick verdicts, clear action steps, and education to stay safe.
          </p>
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <a href="#free-trial" className="px-6 py-3 rounded-md bg-green-600 text-white font-medium text-center hover:bg-green-700 transition-colors">Try Free First</a>
            <a href="#pricing" className="px-6 py-3 rounded-md bg-blue-600 text-white font-medium text-center hover:bg-blue-700 transition-colors">See Plans</a>
            <a href="#how" className="px-6 py-3 rounded-md border border-gray-300 text-gray-700 font-medium text-center hover:bg-gray-50 transition-colors">How it works</a>
          </div>
          <div className="mt-6 flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Fast turnaround
            </div>
            <div className="flex items-center gap-2">🇨🇭 Switzerland-based</div>
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4" />
              Confidential
            </div>
          </div>
        </div>
        <div className="relative">
          <div className="absolute -inset-4 bg-blue-100/60 blur-2xl rounded-full"></div>
          <div className="relative rounded-xl border border-gray-200 bg-white shadow-lg overflow-hidden aspect-video">
            <Image 
              src="https://cdn.abacus.ai/images/79f9d8a2-1e55-4dd3-bb5e-d087aee0644a.png" 
              alt="Professional working on email security analysis" 
              fill
              className="object-cover"
              priority
            />
          </div>
        </div>
      </div>
    </section>
  );
}
