
export default function LanguageSupport() {
  return (
    <section id="languages" className="py-16 bg-gradient-to-r from-blue-50 to-indigo-50">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold">Multi-language Support</h2>
        <p className="mt-3 text-gray-600 text-lg">Our service is available in English, with localization options for Swiss markets</p>
        
        <div className="mt-8 grid md:grid-cols-4 gap-6">
          <div className="p-6 rounded-lg bg-white border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="text-3xl mb-3">🇬🇧</div>
            <h3 className="font-semibold">English</h3>
            <p className="text-sm text-gray-600 mt-2">Primary language - full service available</p>
          </div>
          <div className="p-6 rounded-lg bg-white border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="text-3xl mb-3">🇩🇪</div>
            <h3 className="font-semibold">Deutsch</h3>
            <p className="text-sm text-gray-600 mt-2">Localized responses available on request</p>
          </div>
          <div className="p-6 rounded-lg bg-white border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="text-3xl mb-3">🇫🇷</div>
            <h3 className="font-semibold">Français</h3>
            <p className="text-sm text-gray-600 mt-2">Localized responses available on request</p>
          </div>
          <div className="p-6 rounded-lg bg-white border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="text-3xl mb-3">🇮🇹</div>
            <h3 className="font-semibold">Italiano</h3>
            <p className="text-sm text-gray-600 mt-2">Localized responses available on request</p>
          </div>
        </div>
        
        <div className="mt-8 p-4 rounded-lg bg-blue-100 text-blue-800">
          <p className="text-sm">💡 <strong>How it works:</strong> Simply mention your preferred language (German, French, or Italian) when forwarding suspicious content, and we'll respond in that language.</p>
        </div>
      </div>
    </section>
  );
}
