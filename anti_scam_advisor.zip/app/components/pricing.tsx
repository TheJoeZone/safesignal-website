
import { Check, Gift } from 'lucide-react'

interface PricingCard {
  name: string;
  price: string;
  highlight: boolean;
  features: string[];
  cta: string;
  stripeLink: string;
}

interface PricingProps {
  cards: PricingCard[];
}

export default function Pricing({ cards }: PricingProps) {
  return (
    <section id="pricing" className="py-16 bg-gradient-to-b from-white to-blue-50">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center">Simple, transparent pricing</h2>
        <p className="mt-2 text-center text-gray-600">Choose the protection level that suits your inbox.</p>

        <div className="mt-10 grid md:grid-cols-3 gap-6">
          {cards?.map((c, i) => (
            <div key={i} className={`relative p-6 rounded-xl border ${c?.highlight ? 'border-blue-300 shadow-xl ring-2 ring-blue-100' : 'border-gray-200 shadow'} bg-white hover:shadow-lg transition-shadow` }>
              {c?.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 text-xs rounded-full bg-blue-600 text-white shadow">Most popular</div>
              )}
              <h3 className="text-lg font-semibold">{c?.name}</h3>
              <div className="mt-2 text-3xl font-extrabold">{c?.price}</div>
              <ul className="mt-4 space-y-2 text-sm">
                {c?.features?.map((f, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    {idx === 0 ? <Gift className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" /> : <Check className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />}
                    <span className={idx === 0 ? "text-green-600 font-medium" : ""}>{f}</span>
                  </li>
                ))}
              </ul>
              <a 
                href={c?.stripeLink || '#pricing'} 
                target="_blank" 
                rel="noopener noreferrer" 
                className={`mt-6 inline-block w-full text-center px-4 py-2 rounded-md font-medium transition-colors ${c?.highlight ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-gray-900 text-white hover:bg-black'}`}
              >
                {c?.cta}
              </a>
              <p className="mt-3 text-xs text-gray-500 text-center">Cancel anytime. VAT included where applicable.</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
