
'use client'

import { useState } from 'react'
import { Menu, X } from 'lucide-react'

interface HeaderProps {
  onShowPrivacy: () => void;
  onShowTerms: () => void;
}

export default function Header({ onShowPrivacy, onShowTerms }: HeaderProps) {
  const [open, setOpen] = useState(false);
  
  return (
    <header className="sticky top-0 z-30 bg-white/80 backdrop-blur border-b border-gray-100">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <a href="#home" className="flex items-center gap-2">
          <span className="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-blue-600 text-white font-bold">🛡️</span>
          <span className="font-semibold text-lg">SafeSignal Advisor</span>
        </a>
        <nav className="hidden md:flex items-center gap-6 text-sm">
          <a href="#how" className="hover:text-blue-600 transition-colors">How it works</a>
          <a href="#pricing" className="hover:text-blue-600 transition-colors">Pricing</a>
          <a href="#features" className="hover:text-blue-600 transition-colors">Features</a>
          <a href="#languages" className="hover:text-blue-600 transition-colors">Languages</a>
          <a href="#faq" className="hover:text-blue-600 transition-colors">FAQ</a>
        </nav>
        <div className="hidden md:flex items-center gap-3">
          <a href="#contact" className="text-sm hover:text-blue-600 transition-colors">Contact</a>
          <a href="#free-trial" className="px-4 py-2 rounded-md bg-green-600 text-white text-sm font-medium hover:bg-green-700 transition-colors">Try Free</a>
          <a href="#pricing" className="px-4 py-2 rounded-md bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 transition-colors">Get Started</a>
        </div>
        <button 
          onClick={() => setOpen(!open)} 
          aria-label="Toggle menu" 
          className="md:hidden p-2 rounded hover:bg-gray-100 transition-colors"
        >
          {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>
      {open && (
        <div className="md:hidden border-t border-gray-100 bg-white">
          <div className="px-4 py-3 flex flex-col gap-3 text-sm">
            <a href="#how" className="hover:text-blue-600 transition-colors" onClick={() => setOpen(false)}>How it works</a>
            <a href="#pricing" className="hover:text-blue-600 transition-colors" onClick={() => setOpen(false)}>Pricing</a>
            <a href="#features" className="hover:text-blue-600 transition-colors" onClick={() => setOpen(false)}>Features</a>
            <a href="#languages" className="hover:text-blue-600 transition-colors" onClick={() => setOpen(false)}>Languages</a>
            <a href="#faq" className="hover:text-blue-600 transition-colors" onClick={() => setOpen(false)}>FAQ</a>
            <a href="#contact" className="hover:text-blue-600 transition-colors" onClick={() => setOpen(false)}>Contact</a>
            <a href="#free-trial" className="px-4 py-2 rounded-md bg-green-600 text-white text-sm font-medium text-center transition-colors hover:bg-green-700" onClick={() => setOpen(false)}>Try Free</a>
            <a href="#pricing" className="px-4 py-2 rounded-md bg-blue-600 text-white text-sm font-medium text-center transition-colors hover:bg-blue-700" onClick={() => setOpen(false)}>Get Started</a>
          </div>
        </div>
      )}
    </header>
  );
}
