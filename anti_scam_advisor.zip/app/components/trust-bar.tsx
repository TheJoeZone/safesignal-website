
import { User, Shield, Zap, GraduationCap } from 'lucide-react'

export default function TrustBar() {
  return (
    <section className="py-10 bg-white border-y border-gray-100">
      <div className="max-w-6xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-6 text-sm text-gray-600">
        <div className="flex items-center gap-3">
          <User className="w-4 h-4" />
          1:1 human expert review
        </div>
        <div className="flex items-center gap-3">
          <Shield className="w-4 h-4" />
          Data handled privately
        </div>
        <div className="flex items-center gap-3">
          <Zap className="w-4 h-4" />
          Same-day responses
        </div>
        <div className="flex items-center gap-3">
          <GraduationCap className="w-4 h-4" />
          Learn to spot scams
        </div>
      </div>
    </section>
  );
}
