
'use client'

import { useState } from 'react'
import { Check, Shield, Clock, X } from 'lucide-react'

export default function CTA() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    language: 'en',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      
      if (response?.ok) {
        setSubmitStatus('success');
        setFormData({ name: '', email: '', language: 'en', message: '' });
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <section id="contact" className="py-16">
      <div className="max-w-4xl mx-auto px-4 grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h2 className="text-3xl font-bold">Ready to feel safer online?</h2>
          <p className="mt-3 text-gray-600">
            Tell me what you're seeing. I'll reply with a plan and next steps. No pressure.
          </p>
          <ul className="mt-5 space-y-2 text-sm text-gray-600">
            <li className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-green-600" />
              Same-day replies
            </li>
            <li className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-green-600" />
              Private & confidential
            </li>
            <li className="flex items-center gap-2">
              <X className="w-4 h-4 text-green-600" />
              Cancel anytime
            </li>
          </ul>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 rounded-xl border border-gray-200 bg-white shadow">
          {submitStatus === 'success' && (
            <div className="mb-4 p-3 rounded-md bg-green-50 border border-green-200 text-green-700 text-sm">
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4" />
                Thank you! We'll get back to you within 24 hours.
              </div>
            </div>
          )}
          
          {submitStatus === 'error' && (
            <div className="mb-4 p-3 rounded-md bg-red-50 border border-red-200 text-red-700 text-sm">
              Something went wrong. Please try again or email us directly.
            </div>
          )}
          
          <div className="grid grid-cols-1 gap-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-600 mb-1">Name</label>
              <input 
                id="name"
                name="name"
                type="text" 
                value={formData.name}
                onChange={handleInputChange}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-200 focus:border-blue-400 focus:outline-none transition-colors" 
                placeholder="Your name"
                required
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-600 mb-1">Email</label>
              <input 
                id="email"
                name="email"
                type="email" 
                value={formData.email}
                onChange={handleInputChange}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-200 focus:border-blue-400 focus:outline-none transition-colors" 
                placeholder="you@example.com"
                required
              />
            </div>
            <div>
              <label htmlFor="language" className="block text-sm font-medium text-gray-600 mb-1">Preferred Language</label>
              <select 
                id="language"
                name="language"
                value={formData.language}
                onChange={handleInputChange}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-200 focus:border-blue-400 focus:outline-none transition-colors"
              >
                <option value="en">English</option>
                <option value="de">Deutsch</option>
                <option value="fr">Français</option>
                <option value="it">Italiano</option>
              </select>
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-600 mb-1">What do you need help with?</label>
              <textarea 
                id="message"
                name="message"
                rows={4}
                value={formData.message}
                onChange={handleInputChange}
                className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-200 focus:border-blue-400 focus:outline-none transition-colors" 
                placeholder="Describe the suspicious email/SMS/call or your question..."
                required
              />
            </div>
            <button 
              type="submit"
              disabled={isSubmitting}
              className="mt-2 px-5 py-2 rounded-md bg-blue-600 text-white font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isSubmitting ? 'Sending...' : 'Send message'}
            </button>
            <p className="text-xs text-gray-500">By contacting, you agree not to forward illegal content. We never share your data outside our analysis process.</p>
          </div>
        </form>
      </div>
    </section>
  );
}
