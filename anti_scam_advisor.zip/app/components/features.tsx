
import Image from 'next/image'
import { Users, Lock, BookOpen, MapPin } from 'lucide-react'

export default function Features() {
  const items = [
    {
      title: "Human + Tools",
      desc: "Expert analysis enriched by robust technical checks for links, headers, and sender reputation.",
      icon: <Users className="w-6 h-6" />
    },
    {
      title: "Confidentiality first",
      desc: "Strict privacy practices. We minimize data and never share your content externally.",
      icon: <Lock className="w-6 h-6" />
    },
    {
      title: "Education-forward",
      desc: "Short, practical tips so you learn to spot scams in seconds and stay ahead.",
      icon: <BookOpen className="w-6 h-6" />
    },
    {
      title: "Switzerland-based",
      desc: "Service tailored for Swiss users with CHF pricing and local scam patterns in mind.",
      icon: <MapPin className="w-6 h-6" />
    },
  ];

  return (
    <section id="features" className="py-16">
      <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h2 className="text-3xl font-bold">Built for real-world safety</h2>
          <p className="mt-3 text-gray-600">Most scams rely on urgency and impersonation. We help you slow down, verify, and act confidently.</p>
          <ul className="mt-6 space-y-3">
            {items.map((it, i) => (
              <li key={i} className="flex items-start gap-3">
                <div className="text-blue-600 mt-1">{it.icon}</div>
                <div>
                  <div className="font-semibold">{it.title}</div>
                  <div className="text-gray-600 text-sm">{it.desc}</div>
                </div>
              </li>
            ))}
          </ul>
        </div>
        <div className="relative">
          <div className="absolute -inset-6 bg-blue-100/60 blur-2xl rounded-full"></div>
          <div className="relative rounded-xl border border-gray-200 bg-white shadow-lg overflow-hidden aspect-video">
            <Image 
              src="https://cdn.abacus.ai/images/d11c0fd5-0865-4267-bbdb-04aa1ad9655a.png" 
              alt="Cybersecurity features illustration" 
              fill
              className="object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
