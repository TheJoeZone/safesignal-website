
import { ArrowLeft } from 'lucide-react'

interface FooterProps {
  onShowPrivacy: () => void;
  onShowTerms: () => void;
}

export default function Footer({ onShowPrivacy, onShowTerms }: FooterProps) {
  return (
    <footer className="py-10 bg-white border-t border-gray-100">
      <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-4 gap-8 text-sm">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🛡️</span>
            <span className="font-semibold">SafeSignal Advisor</span>
          </div>
          <p className="mt-3 text-gray-600">Human help to recognize scams in your inbox and on your phone. Swiss-based, privacy-first.</p>
        </div>
        <div>
          <div className="font-semibold mb-2">Company</div>
          <ul className="space-y-2">
            <li><a href="#how" className="hover:text-blue-600 transition-colors">How it works</a></li>
            <li><a href="#pricing" className="hover:text-blue-600 transition-colors">Pricing</a></li>
            <li><a href="#features" className="hover:text-blue-600 transition-colors">Features</a></li>
            <li><a href="#languages" className="hover:text-blue-600 transition-colors">Languages</a></li>
          </ul>
        </div>
        <div>
          <div className="font-semibold mb-2">Legal</div>
          <ul className="space-y-2">
            <li><button onClick={onShowPrivacy} className="hover:text-blue-600 text-left transition-colors">Privacy Policy</button></li>
            <li><button onClick={onShowTerms} className="hover:text-blue-600 text-left transition-colors">Terms of Service</button></li>
            <li><a href="#contact" className="hover:text-blue-600 transition-colors">Contact</a></li>
          </ul>
        </div>
      </div>
      <div className="max-w-6xl mx-auto px-4 mt-6 pt-6 border-t border-gray-100 text-xs text-gray-500">
        © {new Date().getFullYear()} SafeSignal Advisor. All rights reserved.
      </div>
    </footer>
  );
}
