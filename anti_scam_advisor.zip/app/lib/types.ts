
export interface PricingCard {
  name: string
  price: string
  highlight: boolean
  features: string[]
  cta: string
  stripeLink: string
}

export interface FAQ {
  q: string
  a: string
}

export interface ContactFormData {
  name: string
  email: string
  language: string
  message: string
}

export interface ContactSubmissionResponse {
  success: boolean
  message: string
  id?: string
  error?: string
}

export interface FeatureItem {
  title: string
  desc: string
  icon: React.ReactNode
}

export interface Step {
  title: string
  desc: string
  icon: React.ReactNode | string
}

export type SubmitStatus = 'idle' | 'submitting' | 'success' | 'error'

export type Language = 'en' | 'de' | 'fr' | 'it'

export interface LanguageOption {
  code: Language
  name: string
  flag: string
  description: string
}
